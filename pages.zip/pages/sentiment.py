import streamlit as st
import requests
import pandas as pd
import nltk
import matplotlib.pyplot as plt


from nltk.sentiment import SentimentIntensityAnalyzer


# Download VADER lexicon
nltk.download('vader_lexicon')


# Initialize Sentiment Analyzer
sia = SentimentIntensityAnalyzer()


# API Details
API_KEY = "16544bf59711462eae0e71b740050ab3"  # Replace with your actual API key
BASE_URL = "https://newsapi.org/v2/everything"


# Function to fetch news
def fetch_news(sector, days=7):
   url = f"{BASE_URL}?q={sector}&sortBy=publishedAt&apiKey={API_KEY}"
   response = requests.get(url)


   if response.status_code != 200:
       st.error(f"Error fetching news: {response.status_code}")
       return pd.DataFrame()


   data = response.json()
   articles = data.get("articles", [])


   news_data = []
   for article in articles:
       title = article.get("title", "")
       description = article.get("description", "")
       content = article.get("content", "")
       source = article["source"]["name"]
       published_at = article["publishedAt"]


       news_data.append({
           "title": title,
           "description": description,
           "content": content,
           "source": source,
           "published_at": published_at
       })


   return pd.DataFrame(news_data)


# Function to analyze sentiment
def analyze_sentiment(df):
   if df.empty:
       return df


   df["sentiment_score"] = df["description"].fillna("").apply(lambda text: sia.polarity_scores(text)['compound'])


   # Categorize into Positive, Neutral, Negative
   df["sentiment"] = df["sentiment_score"].apply(
       lambda score: "Positive" if score > 0.05 else "Negative" if score < -0.05 else "Neutral")


   return df


# Function to map sentiment to CIBIL score impact
def get_cibil_impact(sentiment_counts, total_articles):
   if total_articles == 0:
       return {"Positive Impact": 0, "Negative Impact": 0, "Neutral Impact": 0}


   positive = (sentiment_counts.get("Positive", 0) / total_articles) * 100
   negative = (sentiment_counts.get("Negative", 0) / total_articles) * 100
   neutral = (sentiment_counts.get("Neutral", 0) / total_articles) * 100


   return {"Positive Impact": positive, "Negative Impact": negative, "Neutral Impact": neutral}


# Streamlit UI
st.title("📊 Business Sector News Sentiment & CIBIL Impact")
with st.sidebar:
    # You can replace the URL below with your own logo URL or local image path
    #st.image("logo.png", use_column_width=True)
    st.markdown("### 📚 CitiBil")
    st.markdown("---")

# Layout for input selection
col1, col2 = st.columns([2, 2])


with col1:
   sectors = ["Banking", "Finance", "Stock Market", "Cryptocurrency", "Real Estate", "Technology"]
   selected_sector = st.selectbox("📂 Select a business sector", sectors)


with col2:
   days = st.slider("📆 Select past days to analyze", min_value=7, max_value=30, value=7, step=1)


# Fetch & analyze news on button click
if st.button("🔍 Analyze Sentiment"):
   with st.spinner("Fetching latest news..."):
       df = fetch_news(selected_sector)


   if not df.empty:
       df = analyze_sentiment(df)


       # Display results
       st.subheader("📰 Sentiment Analysis of Latest News")
       st.dataframe(df[["title", "sentiment", "sentiment_score"]], height=300)


       # Summary of sentiment
       sentiment_counts = df["sentiment"].value_counts().to_dict()
       cibil_impact = get_cibil_impact(sentiment_counts, len(df))


       # Show Sentiment Summary as Bar Chart
       st.subheader("📊 Sentiment Distribution")
       st.bar_chart(sentiment_counts)


       # Pie Chart Layout for CIBIL Impact
       st.subheader("📌 CIBIL Score Impact Visualization")


       fig, ax = plt.subplots(figsize=(4, 4))  # Adjust size for smaller pie chart
       labels = list(cibil_impact.keys())
       values = list(cibil_impact.values())
       colors = ["#28a745", "#dc3545", "#ffc107"]  # Green, Red, Yellow for Positive, Negative, Neutral


       ax.pie(values, labels=labels, autopct='%1.1f%%', startangle=90, colors=colors)
       ax.axis('equal')  # Ensures it's a circle


       # Centering the pie chart
       st.markdown("<div style='display: flex; justify-content: center;'>", unsafe_allow_html=True)
       st.pyplot(fig)
       st.markdown("</div>", unsafe_allow_html=True)


   else:
       st.warning("⚠ No news articles found for this sector.")